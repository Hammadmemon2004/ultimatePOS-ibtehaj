<?php

return [
    'name' => 'Cms',
    'module_version' => '1.2',
    'pid' => 15,
];
